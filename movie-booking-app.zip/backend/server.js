const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const db = require('./database');

const app = express();
app.use(cors());
app.use(bodyParser.json());

// Signup
app.post('/signup', (req, res) => {
  const { username, password } = req.body;
  db.run(`INSERT INTO users (username, password) VALUES (?, ?)`,
    [username, password], function (err) {
      if (err) return res.status(400).send({ error: "User already exists" });
      res.send({ userId: this.lastID });
    });
});

// Login
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get(`SELECT * FROM users WHERE username = ? AND password = ?`,
    [username, password], (err, row) => {
      if (row) res.send({ success: true, userId: row.id });
      else res.status(401).send({ error: "Invalid credentials" });
    });
});

// Get Movies
app.get('/movies', (req, res) => {
  db.all(`SELECT * FROM movies`, [], (err, rows) => {
    res.send(rows);
  });
});

// Book Ticket
app.post('/book', (req, res) => {
  const { userId, movieId, seat } = req.body;
  db.run(`INSERT INTO bookings (userId, movieId, seat) VALUES (?, ?, ?)`,
    [userId, movieId, seat], function (err) {
      if (err) return res.status(500).send({ error: "Booking failed" });
      res.send({ success: true });
    });
});

app.listen(3000, () => console.log('Server running on port 3000'));
