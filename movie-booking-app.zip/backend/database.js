const sqlite3 = require('sqlite3').verbose();
const db = new sqlite3.Database(':memory:'); // Use file.db for persistent

db.serialize(() => {
  db.run(`CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE,
    password TEXT
  )`);

  db.run(`CREATE TABLE movies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT,
    description TEXT
  )`);

  db.run(`CREATE TABLE bookings (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    userId INTEGER,
    movieId INTEGER,
    seat TEXT,
    FOREIGN KEY(userId) REFERENCES users(id),
    FOREIGN KEY(movieId) REFERENCES movies(id)
  )`);

  db.run(`INSERT INTO movies (title, description) VALUES 
    ('Avengers', 'Superhero movie'),
    ('Inception', 'Sci-fi thriller')
  `);
});

module.exports = db;
