function signup() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  fetch("http://localhost:3000/signup", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  }).then(res => res.json()).then(res => {
    if (res.userId) {
      localStorage.setItem("userId", res.userId);
      window.location.href = "movies.html";
    } else {
      alert("Signup failed!");
    }
  });
}

function login() {
  const username = document.getElementById("username").value;
  const password = document.getElementById("password").value;
  fetch("http://localhost:3000/login", {
    method: "POST",
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password })
  }).then(res => res.json()).then(res => {
    if (res.success) {
      localStorage.setItem("userId", res.userId);
      window.location.href = "movies.html";
    } else {
      alert("Login failed!");
    }
  });
}